﻿using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using CodeBase.Netcore.NetworkComponents.RPCComponents;
using CodeBase.Netcore.RPCSystem;
using CodeBase.Netcore.RPCSystem.ProcessorsData;
using UnityEngine;
using UnityEngine.AddressableAssets;

namespace CodeBase.Netcore.Spawner.ObjectsSyncer
{
    public class NetworkObjectsSyncer : INetworkObjectSyncer
    {
        private readonly Dictionary<int, GameObject> _networkObjects = new();

        public IReadOnlyDictionary<int, GameObject> NetworkObjects =>
            _networkObjects;

        private readonly MethodInfo _spawnMethodInfo = typeof(NetworkSpawner).GetMethod("SpawnClientRpc");

        public void AddNetworkObject(GameObject gameObject, int uniqueId)
        {
            _networkObjects.Add(uniqueId, gameObject);
        }

        public void RemoveNetworkObject(int objectId)
        {
            Object.Destroy(_networkObjects[objectId]);
            _networkObjects.Remove(objectId);
        }

        public bool CheckSyncObject(GameObject prefabId, int uniqueId) =>
            _networkObjects.Any(networkObject => networkObject.Key == uniqueId);

        public void Sync(NetworkSpawner networkSpawner)
        {
            foreach (var networkObject in _networkObjects)
            {
                RPCInvoker.InvokeServiceRPC<NetworkSpawner>(networkSpawner, _spawnMethodInfo,
                    NetProtocolType.Tcp, 
                    networkObject.Value.GetComponent<NetworkBehaviour>().PrefabGUID,
                    networkObject.Key,
                    networkObject.Value.transform.position,
                    networkObject.Value.transform.rotation, 
                    networkObject.Value.transform.localScale);
            }
        }
    }

    public interface INetworkObjectSyncer
    {
        public IReadOnlyDictionary<int, GameObject> NetworkObjects { get; }
        void Sync(NetworkSpawner networkSpawner);
        void AddNetworkObject(GameObject gameObject, int uniqueId);
        bool CheckSyncObject(GameObject prefabId, int uniqueId);
        void RemoveNetworkObject(int objectId);
    }
}