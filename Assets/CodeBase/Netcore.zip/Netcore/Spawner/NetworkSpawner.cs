﻿using System;
using System.Reflection;
using _Scripts.Netcore.Data.NetworkObjects;
using CodeBase.Infrastructure.Services.Asset;
using CodeBase.Netcore.Data.Attributes;
using CodeBase.Netcore.Editor;
using CodeBase.Netcore.NetworkComponents.RPCComponents;
using CodeBase.Netcore.RPCSystem;
using CodeBase.Netcore.RPCSystem.ProcessorsData;
using CodeBase.Netcore.Runner;
using CodeBase.Netcore.Spawner.ObjectsSyncer;
using UnityEngine;
using VContainer;
using VContainer.Unity;

namespace CodeBase.Netcore.Spawner
{
    public class NetworkSpawner : NetworkService, INetworkSpawner, IDisposable
    {
        private readonly IObjectResolver _resolver;
        private readonly INetworkObjectSyncer _networkObjectSyncer;
        private readonly INetworkRunner _networkRunner;
        private readonly IAssetProvider _assetProvider;
        private readonly NetworkObjectsConfig _objectsConfig;
        private readonly MethodInfo _spawnMethodInfo = typeof(NetworkSpawner).GetMethod(nameof(SpawnClientRpc));
        private readonly MethodInfo _destroyMethodInfo = typeof(NetworkSpawner).GetMethod(nameof(DestroyClientRpc));

        private int _uniqueId = 0;

        public NetworkSpawner(IObjectResolver resolver,
            INetworkObjectSyncer networkObjectSyncer,
            INetworkRunner networkRunner,
            IAssetProvider assetProvider,
            NetworkObjectsConfig objectsConfig)
        {
            _resolver = resolver;
            _networkObjectSyncer = networkObjectSyncer;
            _networkRunner = networkRunner;
            _assetProvider = assetProvider;
            _objectsConfig = objectsConfig;

            _networkRunner.OnPlayerConnected += Sync;
            RPCInvoker.RegisterRPCInstance<NetworkSpawner>(this);
        }

        public GameObject Spawn(GameObject prefab, Transform transform = null) =>
            SpawnLocal(prefab, Vector3.zero, Quaternion.identity, Vector3.one, transform);

        public GameObject Spawn(GameObject prefab, Vector3 position,
            Transform transform = null) =>
            SpawnLocal(prefab, position, Quaternion.identity, Vector3.one, transform);

        public GameObject Spawn(GameObject prefab, Vector3 position, Quaternion rotation,
            Transform transform = null) =>
            SpawnLocal(prefab, position, rotation, Vector3.one, transform);

        public GameObject Spawn(GameObject prefab, Vector3 position, Quaternion rotation,
            Vector3 scale, Transform transform = null) =>
            SpawnLocal(prefab, position, rotation, Vector3.one, transform);

        public void Sync() =>
            _networkObjectSyncer.Sync(this);

        private void Sync(int id)
        {
            _networkObjectSyncer.Sync(this);
        }

        private GameObject SpawnLocal(GameObject prefab, Vector3 position,
            Quaternion rotation, Vector3 scale, Transform transform)
        {
            if (!_networkRunner.IsServer)
                return null;

            if (prefab.GetComponentInChildren<INetworkComponent>() == null)
                return null;

            GameObject go = _resolver.Instantiate(prefab, position, rotation, transform);
            go.transform.localScale = scale;

            _networkObjectSyncer.AddNetworkObject(go, _uniqueId);

            _uniqueId++;


            RPCInvoker.InvokeServiceRPC<NetworkSpawner>(this, _spawnMethodInfo,
                NetProtocolType.Tcp, go.GetComponent<NetworkBehaviour>().PrefabGUID,
                go.GetComponent<NetworkBehaviour>().InstanceId, position, rotation, scale);

            return go;
        }

        [ClientRPC]
        public void SpawnClientRpc(string reference, int uniqueId, Vector3 position,
            Quaternion rotation, Vector3 scale)
        {
            GameObject prefab = _objectsConfig.NetworkObjectsDictionary[reference].gameObject;

            if (_networkObjectSyncer.CheckSyncObject(prefab, uniqueId))
                return;

            GameObject networkObj = _resolver.Instantiate(prefab, position, rotation);
            networkObj.transform.localScale = scale;

            networkObj.GetComponent<NetworkBehaviour>().isDestroy += DestroyClientObject;

            _networkObjectSyncer.AddNetworkObject(networkObj, uniqueId);
        }

        [ClientRPC]
        public void DestroyClientRpc(int uniqueId)
        {
            _networkObjectSyncer.RemoveNetworkObject(uniqueId);
        }

        private void DestroyClientObject(int uniqueId, NetworkBehaviour networkObj)
        {
            RPCInvoker.InvokeServiceRPC<NetworkSpawner>(this, _destroyMethodInfo, NetProtocolType.Tcp, uniqueId);
            networkObj.isDestroy -= DestroyClientObject;
        }

        public void Dispose() =>
            _networkRunner.OnPlayerConnected -= Sync;
    }
}