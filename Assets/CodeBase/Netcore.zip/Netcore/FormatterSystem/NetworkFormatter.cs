﻿using CodeBase.GameLogic.Common;
using CodeBase.Netcore.FormatterSystem.Formatters;
using MessagePack;
using MessagePack.Formatters;
using MessagePack.Resolvers;
using QuaternionFormatter = CodeBase.Netcore.FormatterSystem.Formatters.QuaternionFormatter;
using Vector3Formatter = CodeBase.Netcore.FormatterSystem.Formatters.Vector3Formatter;

namespace CodeBase.Netcore.FormatterSystem
{
    public class NetworkFormatter : INetworkFormatter
    {
        public void Initialize()
        {
            var formatters = new IMessagePackFormatter[]
            {
                new Vector3Formatter(),
                new Vector2Formatter(),
                new QuaternionFormatter(),
                new AssetReferenceGameObjectFormatter(),
                new InputFormatter()
            };

            var resolvers = new IFormatterResolver[]
            {
                StandardResolver.Instance 
            };
            
            var options = MessagePackSerializerOptions.Standard
                .WithResolver(CompositeResolver.Create(formatters, resolvers));

            MessagePackSerializer.DefaultOptions = options;
        }
    }

    public interface INetworkFormatter
    {
        void Initialize();
    }
}