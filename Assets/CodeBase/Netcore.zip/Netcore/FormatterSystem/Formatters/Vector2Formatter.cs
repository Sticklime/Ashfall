﻿using MessagePack;
using MessagePack.Formatters;
using UnityEngine;

public class Vector2Formatter : IMessagePackFormatter<Vector2>
{
    public void Serialize(ref MessagePackWriter writer, Vector2 value, MessagePackSerializerOptions options)
    {
        writer.WriteArrayHeader(2);
        writer.Write(value.x);
        writer.Write(value.y);
    }

    public Vector2 Deserialize(ref MessagePackReader reader, MessagePackSerializerOptions options)
    {
        var count = reader.ReadArrayHeader();
        if (count != 2)
            throw new MessagePackSerializationException("Vector2 must have 2 elements");

        float x = reader.ReadSingle();
        float y = reader.ReadSingle();

        return new Vector2(x, y);
    }
}