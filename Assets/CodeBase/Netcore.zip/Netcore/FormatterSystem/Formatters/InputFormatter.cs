﻿using MessagePack;
using MessagePack.Formatters;
using UnityEngine;
using Input = CodeBase.GameLogic.Common.Input;

namespace CodeBase.Netcore.FormatterSystem.Formatters
{
    public class InputFormatter : IMessagePackFormatter<Input>
    {
        public void Serialize(ref MessagePackWriter writer, Input value, MessagePackSerializerOptions options)
        {
            writer.WriteArrayHeader(4);
            
            var vec2Formatter = options.Resolver.GetFormatterWithVerify<Vector2>();

            vec2Formatter.Serialize(ref writer, value.Move, options);
            vec2Formatter.Serialize(ref writer, value.Look, options);
            writer.Write(value.JumpTriggered);
            writer.Write(value.SprintProgress);
        }

        public Input Deserialize(ref MessagePackReader reader, MessagePackSerializerOptions options)
        {
            var count = reader.ReadArrayHeader();

            var vec2Formatter = options.Resolver.GetFormatterWithVerify<Vector2>();

            Input input = new Input();

            if (count >= 1)
                input.Move = vec2Formatter.Deserialize(ref reader, options);
            if (count >= 2)
                input.Look = vec2Formatter.Deserialize(ref reader, options);
            if (count >= 3)
                input.JumpTriggered = reader.ReadBoolean();
            if (count >= 4)
                input.SprintProgress = reader.ReadBoolean();
            
            for (int i = 4; i < count; i++)
                reader.Skip();

            return input;
        }
    }
}