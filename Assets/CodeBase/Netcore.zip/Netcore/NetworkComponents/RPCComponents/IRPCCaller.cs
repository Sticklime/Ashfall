namespace CodeBase.Netcore.NetworkComponents.RPCComponents
{
    public interface IRPCCaller
    {
    }
}