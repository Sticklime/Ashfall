using System;
using System.Threading;
using UnityEngine;

namespace CodeBase.Netcore.NetworkComponents.RPCComponents
{
    public abstract class NetworkBehaviour : MonoBehaviour, IRPCCaller, INetworkComponent
    {
        private static int _instanceCounter;
        public event Action<int, NetworkBehaviour> isDestroy;

        [field: SerializeField] public string PrefabGUID { get; set; }

        public int InstanceId { get; private set; }

        public void InitializeNetworkBehaviour() =>
            InstanceId = Interlocked.Increment(ref _instanceCounter);

        private void OnDestroy() => isDestroy?.Invoke(InstanceId, this);
    }

    public interface INetworkComponent
    {
    }
}