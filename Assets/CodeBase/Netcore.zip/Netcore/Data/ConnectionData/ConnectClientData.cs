﻿using System.Net;

namespace CodeBase.Netcore.Data.ConnectionData
{
    public struct ConnectClientData
    {
        public IPAddress Ip;
        public int TcpPort;
        public int UdpPort;
    }
}