﻿namespace CodeBase.Netcore.Data.ConnectionData
{
    public struct ConnectServerData
    {
        public int TcpPort;
        public int UdpPort;
        public int MaxClients;
    }
}