﻿using System.Collections.Generic;
using CodeBase.Netcore.NetworkComponents.RPCComponents;
using UnityEngine;

namespace _Scripts.Netcore.Data.NetworkObjects
{
    [CreateAssetMenu(menuName = "Network/Configs/NetworkObjects", fileName = "NetworkObjectsConfig")]
    public class NetworkObjectsConfig : ScriptableObject
    {
        [SerializeField] private List<NetworkBehaviour> _networkObjects = new();
        
        private Dictionary<string, NetworkBehaviour> _networkObjectsDictionary = new();
        public List<NetworkBehaviour> NetworkObjects => _networkObjects;
        public Dictionary<string, NetworkBehaviour> NetworkObjectsDictionary => _networkObjectsDictionary;

        public void InitializeNetworkObjects()
        {
            _networkObjectsDictionary = new Dictionary<string, NetworkBehaviour>();
            
            foreach (var obj in _networkObjects)
            {
                _networkObjectsDictionary.TryAdd(obj.PrefabGUID, obj);
            }
        }
    }
}