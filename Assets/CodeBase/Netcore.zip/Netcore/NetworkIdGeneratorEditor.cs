﻿using System;
using System.Collections.Generic;
using System.Linq;
using _Scripts.Netcore.Data.NetworkObjects;
using CodeBase.Netcore.NetworkComponents.RPCComponents;
using UnityEditor;
using UnityEngine;

namespace CodeBase.Netcore.Editor
{
    public static class NetworkIdGeneratorEditor
    {
        private const string CONFIG_PATH = "Assets/CodeBase/Netcore/Data/Config/NetworkObjectsConfig.asset";

        [MenuItem("Tools/Generate Network IDs and Build Dictionary")]
        public static void GenerateNetworkIds()
        {
            NetworkObjectsConfig config = AssetDatabase.LoadAssetAtPath<NetworkObjectsConfig>(CONFIG_PATH);
            Debug.Log(config.name);
            config.NetworkObjects.Clear();

            string[] guids = AssetDatabase.FindAssets("t:Prefab");
            int processedCount = 0;
            int modifiedCount = 0;

            foreach (string guid in guids)
            {
                string path = AssetDatabase.GUIDToAssetPath(guid);
                GameObject prefab = AssetDatabase.LoadAssetAtPath<GameObject>(path);
                if (prefab == null) continue;

                GameObject instance = (GameObject)PrefabUtility.InstantiatePrefab(prefab);
                bool modified = false;

                NetworkBehaviour[] networkComponents = instance.GetComponentsInChildren<NetworkBehaviour>(true);
                string id = Guid.NewGuid().ToString();

                foreach (var net in networkComponents)
                {
                    if (config.NetworkObjects.All(x => x.PrefabGUID != id))
                    {
                        net.PrefabGUID = id;
                        modified = true;
                        modifiedCount++;
                        Debug.LogWarning($"Add ID '{id}' found for prefab at: {path}");
                    }
                    else
                    {
                        Debug.LogWarning($"Duplicate ID '{id}' found for prefab at: {path}");
                    }
                }

                if (networkComponents.Length > 0)
                    config.NetworkObjects.Add(prefab.GetComponent<NetworkBehaviour>());

                if (modified)
                {
                    PrefabUtility.SaveAsPrefabAsset(instance, path);
                }

                GameObject.DestroyImmediate(instance);
                processedCount++;
            }


            Debug.Log(
                $"[NetworkIdGenerator] Processed {processedCount} prefabs. Modified {modifiedCount} and added to dictionary.");
        }
    }
}