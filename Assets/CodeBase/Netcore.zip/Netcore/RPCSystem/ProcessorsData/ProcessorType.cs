﻿namespace CodeBase.Netcore.RPCSystem.ProcessorsData
{
    public enum ProcessorType
    {
        Send = 0,
        Receive = 1
    }
}