﻿namespace CodeBase.Netcore.RPCSystem.ProcessorsData
{
    public enum NetProtocolType
    {
        Tcp = 0,
        Udp = 1
    }
}