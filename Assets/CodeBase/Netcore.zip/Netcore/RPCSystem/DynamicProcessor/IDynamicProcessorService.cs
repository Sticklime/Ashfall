﻿namespace CodeBase.Netcore.RPCSystem.DynamicProcessor
{
    public interface IDynamicProcessorService
    {
        void Initialize();
    }
}