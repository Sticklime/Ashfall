﻿using _Scripts.Netcore.Data.NetworkObjects;
using CodeBase.Netcore.FormatterSystem;
using CodeBase.Netcore.NetworkComponents.NetworkVariableComponent.Processor;
using CodeBase.Netcore.RPCSystem;
using CodeBase.Netcore.RPCSystem.Callers;
using CodeBase.Netcore.RPCSystem.DynamicProcessor;
using CodeBase.Netcore.RPCSystem.Processors;
using CodeBase.Netcore.Runner;

namespace CodeBase.Netcore.Initializer
{
    public class NetworkInitializer : INetworkInitializer
    {
        private readonly INetworkFormatter _networkFormatter;
        private readonly IRPCSendProcessor _rpcSendProcessor;
        private readonly IDynamicProcessorService _dynamicProcessorService;
        private readonly ICallerService _callerService;
        private readonly NetworkObjectsConfig _networkObjectsConfig;

        public NetworkInitializer(INetworkFormatter networkFormatter,
            IRPCSendProcessor rpcSendProcessor,
            IDynamicProcessorService dynamicProcessorService,
            ICallerService callerService, NetworkObjectsConfig networkObjectsConfig)
        {
            _networkFormatter = networkFormatter;
            _rpcSendProcessor = rpcSendProcessor;
            _dynamicProcessorService = dynamicProcessorService;
            _callerService = callerService;
            _networkObjectsConfig = networkObjectsConfig;
        }

        public void Initialize(INetworkRunner networkRunner)
        {
            _networkObjectsConfig.InitializeNetworkObjects();
            _networkFormatter.Initialize();
            _dynamicProcessorService.Initialize();
            _rpcSendProcessor.Initialize(networkRunner);
            RPCInvoker.Initialize(_rpcSendProcessor, _callerService);
            NetworkVariableProcessor.Instance.Initialize(networkRunner);
        }
    }

    public interface INetworkInitializer
    {
        void Initialize(INetworkRunner networkRunner);
    }
}